import cv2
import serial
import time
import gspread
from oauth2client.service_account import ServiceAccountCredentials

try:
   
    ser = serial.Serial('COM5', baudrate=115200, timeout=1) 
except serial.SerialException as e:
    print(f"Error opening serial port: {e}")
    exit(1)


face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')


cap = cv2.VideoCapture(0)

if not cap.isOpened():
    print("Error: Could not open video capture.")
    ser.close()
    exit(1)


scope = ["https://spreadsheets.google.com/feeds", "https://www.googleapis.com/auth/drive"]
creds = ServiceAccountCredentials.from_json_keyfile_name("path_to_your_json_file.json", scope)
client = gspread.authorize(creds)
sheet = client.open("lcddata").sheet1  

while True:
    
    ret, frame = cap.read()
    if not ret:
        print("Error: Failed to capture image.")
        break

    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    
    faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))

    
    for (x, y, w, h) in faces:
        cv2.rectangle(frame, (x, y), (x+w, y+h), (255, 0, 0), 2)

    
    if len(faces) > 0:
        ser.write(b'1')  
        face_detected = "Face detected"
        lights_status = "LIGHTS ON"
        fan_status = "FANS ON"
    else:
        ser.write(b'0')  
        face_detected = "No face detected"
        lights_status = "LIGHTS OFF"
        fan_status = "FANS OFF"

    
    sheet.append_row([time.strftime("%Y-%m-%d %H:%M:%S"), face_detected, lights_status, fan_status])

    
    cv2.imshow('Video', frame)

    
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break


cap.release()
cv2.destroyAllWindows()
ser.close()

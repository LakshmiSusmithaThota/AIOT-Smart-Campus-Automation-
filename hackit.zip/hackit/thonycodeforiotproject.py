from machine import Pin, I2C
from time import sleep
from sys import stdin
from lcd_api import LcdApi
from pico_i2c_lcd import I2cLcd

# Initialize pins
led1 = Pin(0, Pin.OUT)
led2 = Pin(1, Pin.OUT)
led3 = Pin(2, Pin.OUT)
led4 = Pin(3, Pin.OUT)
buzzer = Pin(4, Pin.OUT)

# Initialize LEDs and buzzer to off
led1.value(0)
led2.value(0)
led3.value(0)
led4.value(0)
buzzer.value(0)

# I2C configuration for LCD
I2C_ADDR = 0x27  # Update if necessary
I2C_NUM_ROWS = 2
I2C_NUM_COLS = 16
i2c = I2C(1, sda=Pin(6), scl=Pin(7), freq=400000)  # Update to GP6 and GP7

# Initialize LCD
lcd = I2cLcd(i2c, I2C_ADDR, I2C_NUM_ROWS, I2C_NUM_COLS)
lcd.clear()

def display_message(message):
    lcd.clear()
    lcd.putstr(message)

while True:
    input_character = stdin.read(1)
    if input_character == '1':
        led1.value(1)
        led2.value(1)
        led3.value(1)
        led4.value(1)
        buzzer.value(1)
        display_message("Face detected\nLights & fan ON")
    elif input_character == '0':
        led1.value(0)
        led2.value(0)
        led3.value(0)
        led4.value(0)
        buzzer.value(0)
        display_message("No face detected\nLights & fan OFF")

